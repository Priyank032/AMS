import React from "react";
import Dashboard_new from "../Pages/Dba/Dashboard_new";
import TeacherDashboard from "../Pages/Teacher/TeacherDashboard";
import YoutubePanel from "../Pages/Student/components/YoutubePanel";
import Teacher_form from "../Pages/Dba/Teacher_form";
import Student_Form from "../Pages/Dba/Student_Form";
import All_Teachers from "../Pages/Dba/All_Teachers"
import All_Students from "../Pages/Dba/All_Students"
import StudentData from "../Pages/Teacher/StudentData"
import StudentMarksData from "../Pages/Teacher/StudentMarksData"
import UpdateStudentAttendenceData from "../Pages/Teacher/UpdateStudentAttendenceData"
import UpdateStudentMarksData from "../Pages/Teacher/UpdateStudentMarksData"
import All_Fees_Details from "../Pages/Dba/All_Fees_Details"
import Edit_Teacher from '../Pages/Dba/Edit_Teacher';
import Edit_Student from '../Pages/Dba/Edit_Student';
import FeesAdd from '../Pages/Dba/FeesAdd';
import Edit_Fees from '../Pages/Dba/Edit_Fees';

import Footer from "./Footer";
import { useLocation } from 'react-router-dom'
import Login from "../Pages/Login";
const Content = (props) => {

  const location = useLocation();
    
    var contentClass = props.isOpen ? "content open" : "content";
    return <div className={contentClass}>
        <div className="DataInContent">

      {	location.pathname === '/Dba' ?   <Dashboard_new/> : console.log()}
      {	location.pathname === '/Dba/Add_Teacher' ?   <Teacher_form/> : console.log()}
      {	location.pathname === '/Dba/Add_Student' ?   <Student_Form/> : console.log()}
      {	location.pathname === '/Dba/All_Teachers' ?   <All_Teachers/> : console.log()}
      {	location.pathname === '/Dba/All_Students' ?   <All_Students/> : console.log()}
      {	location.pathname === '/Dba/All_Fees_Details' ?   <All_Fees_Details/> : console.log()}
      {	/\/Dba\/edit_Teacher/.test(location.pathname) ?  <Edit_Teacher/> : console.log()}
      {	/\/Dba\/edit_Student/.test(location.pathname) ?  <Edit_Student/> : console.log()}
      {	/\/Dba\/Add_Fees/.test(location.pathname) ?  <FeesAdd/> : console.log()}
      {	/\/Dba\/edit_feeDetail/.test(location.pathname) ?  <Edit_Fees/> : console.log()}
    
      {	location.pathname === '/Teacher' ?   <TeacherDashboard/> : console.log()}
      {	location.pathname === '/Teacher/Add_Attendence' ?   <StudentData/> : console.log()}
      {	location.pathname === '/Teacher/Add_Marks' ?   <StudentMarksData/> : console.log()}
      {	location.pathname === '/Teacher/update_Attendence' ?   <UpdateStudentAttendenceData/> : console.log()}
      {	location.pathname === '/Teacher/update_Marks' ?   <UpdateStudentMarksData/> : console.log()}
      {	location.pathname === '/Student' ?   <YoutubePanel/> : console.log()}
        </div>
      {/* <Footer/> */}
      
    </div>;
  }

export default Content;
