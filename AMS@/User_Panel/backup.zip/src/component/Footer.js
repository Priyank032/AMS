import React from 'react'

const Footer = () => {
  return (
    // <footer className='Footer'>
    //   <div className='container'>
    //         <div className='row'>
    //             <div className='col-lg-2 col-md-12 '></div>
    //             <div className='col-lg-8 col2'><p>Copyright@Aurbitus_2021</p></div> 
    //             <div className='col-lg-2 col3 col-md-12 '></div> 
    //         </div>
    //   </div>
    // </footer>
    <div className='myFooter'>
    <footer className=' bg-dark text-light mt-4 '>
        <div className='d-flex justify-content-center '>
            copyright@Aurbitus_2021
        </div>
    </footer>
    </div>
  )
}

export default Footer
