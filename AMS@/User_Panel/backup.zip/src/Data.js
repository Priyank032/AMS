// const Data =["harry","larry","harry","larry","harry","larry","harry","larry","harry","larry","harry","larry","harry","larry"]
// export default Data;

const  tags= {
    Class5:{
        tag:["class 5 maths","class 5 gk","class 5 english","class 5 social","class 5 hindi","class 5 science"]
    },
    Class6:{
        tag:["class 5 maths","class 5 gk","class 5 english","class 5 social","class 5 hindi","class 5 science"]
    }
}
export default tags;