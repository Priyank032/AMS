import React,{useEffect} from 'react'
import {useNavigate } from "react-router-dom";
const TeacherDashboard = () => {
    const history = useNavigate();

    useEffect(() => {
        const TeacherInfo = JSON.parse(localStorage.getItem("Teacher"));
        //console.log(userInfo._id);
        if (!TeacherInfo) {
            history("/");
            return
        } else {

            localStorage.setItem("TeacherID", TeacherInfo.Teacher._id);
            localStorage.setItem("InstituteID", TeacherInfo.Teacher.institutionId);
            // getAllStudents();
        }
    }, [history]);

  return (
    <div>TeacherDashboard</div>
  )
}

export default TeacherDashboard